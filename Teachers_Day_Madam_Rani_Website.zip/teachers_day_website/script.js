const music=document.getElementById("bgMusic"), btn=document.getElementById("musicBtn");
btn.addEventListener("click", async()=>{
  try{
    if(music.paused){await music.play();btn.innerHTML="♫ <span>Pause</span>";}
    else{music.pause();btn.innerHTML="♫ <span>Music</span>";}
  }catch(e){alert("Add your music file as music/teacher-day.mp3, then tap the music button again.");}
});
const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add("visible")}),{threshold:.12});
document.querySelectorAll(".reveal").forEach(x=>observer.observe(x));
function petal(){
 const p=document.createElement("i");p.className="petal";p.style.left=Math.random()*100+"vw";p.style.animationDuration=(5+Math.random()*7)+"s";p.style.transform=`rotate(${Math.random()*360}deg)`;
 document.getElementById("petals").appendChild(p);setTimeout(()=>p.remove(),13000);
}
setInterval(petal,650);
